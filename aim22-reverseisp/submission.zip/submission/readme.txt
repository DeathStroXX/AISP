
runtime per frame [s] : 0.0036
CPU[1] / GPU[0] : 1
Extra Data [1] / No Extra Data [0] : 0
Other description : Baseline UNet submission https://github.com/mv-lab/AISP
